package com.fms.email.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * FeedbackQuestions
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2020-01-24T12:20:46.638+05:30[Asia/Calcutta]")
public class FeedbackQuestions   {
  @JsonProperty("questions")
  private String questions = null;

  @JsonProperty("totalAnswers")
  private Integer totalAnswers = null;

  @JsonProperty("feedBackType")
  private String feedBackType = null;

  public FeedbackQuestions questions(String questions) {
    this.questions = questions;
    return this;
  }

  /**
   * Get questions
   * @return questions
  **/
  @ApiModelProperty(value = "")
  
    public String getQuestions() {
    return questions;
  }

  public void setQuestions(String questions) {
    this.questions = questions;
  }

  public FeedbackQuestions totalAnswers(Integer totalAnswers) {
    this.totalAnswers = totalAnswers;
    return this;
  }

  /**
   * Get totalAnswers
   * @return totalAnswers
  **/
  @ApiModelProperty(value = "")
  
    public Integer getTotalAnswers() {
    return totalAnswers;
  }

  public void setTotalAnswers(Integer totalAnswers) {
    this.totalAnswers = totalAnswers;
  }

  public FeedbackQuestions feedBackType(String feedBackType) {
    this.feedBackType = feedBackType;
    return this;
  }

  /**
   * Get feedBackType
   * @return feedBackType
  **/
  @ApiModelProperty(value = "")
  
    public String getFeedBackType() {
    return feedBackType;
  }

  public void setFeedBackType(String feedBackType) {
    this.feedBackType = feedBackType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FeedbackQuestions feedbackQuestions = (FeedbackQuestions) o;
    return Objects.equals(this.questions, feedbackQuestions.questions) &&
        Objects.equals(this.totalAnswers, feedbackQuestions.totalAnswers) &&
        Objects.equals(this.feedBackType, feedbackQuestions.feedBackType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(questions, totalAnswers, feedBackType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FeedbackQuestions {\n");
    
    sb.append("    questions: ").append(toIndentedString(questions)).append("\n");
    sb.append("    totalAnswers: ").append(toIndentedString(totalAnswers)).append("\n");
    sb.append("    feedBackType: ").append(toIndentedString(feedBackType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
