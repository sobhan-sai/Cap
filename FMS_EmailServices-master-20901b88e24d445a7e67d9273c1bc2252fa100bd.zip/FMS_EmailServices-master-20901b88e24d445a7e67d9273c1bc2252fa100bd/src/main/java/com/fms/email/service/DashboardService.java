package com.fms.email.service;

import java.util.Map;

public interface DashboardService {
	 Map getDashboardSummary();
}
