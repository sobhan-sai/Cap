package com.fms.email.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * EmailDetails
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2020-01-24T12:20:46.638+05:30[Asia/Calcutta]")
public class EmailDetails   {
  @JsonProperty("fromAddress")
  private String fromAddress = null;

  @JsonProperty("body")
  private String body = null;

  @JsonProperty("toPartcipantAddress")
  @Valid
  private List<String> toPartcipantAddress = null;

  public EmailDetails fromAddress(String fromAddress) {
    this.fromAddress = fromAddress;
    return this;
  }

  /**
   * Get fromAddress
   * @return fromAddress
  **/
  @ApiModelProperty(value = "")
  
    public String getFromAddress() {
    return fromAddress;
  }

  public void setFromAddress(String fromAddress) {
    this.fromAddress = fromAddress;
  }

  public EmailDetails body(String body) {
    this.body = body;
    return this;
  }

  /**
   * Get body
   * @return body
  **/
  @ApiModelProperty(value = "")
  
    public String getBody() {
    return body;
  }

  public void setBody(String body) {
    this.body = body;
  }

  public EmailDetails toPartcipantAddress(List<String> toPartcipantAddress) {
    this.toPartcipantAddress = toPartcipantAddress;
    return this;
  }

  public EmailDetails addToPartcipantAddressItem(String toPartcipantAddressItem) {
    if (this.toPartcipantAddress == null) {
      this.toPartcipantAddress = new ArrayList<>();
    }
    this.toPartcipantAddress.add(toPartcipantAddressItem);
    return this;
  }

  /**
   * Get toPartcipantAddress
   * @return toPartcipantAddress
  **/
  @ApiModelProperty(value = "")
  
    public List<String> getToPartcipantAddress() {
    return toPartcipantAddress;
  }

  public void setToPartcipantAddress(List<String> toPartcipantAddress) {
    this.toPartcipantAddress = toPartcipantAddress;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EmailDetails emailDetails = (EmailDetails) o;
    return Objects.equals(this.fromAddress, emailDetails.fromAddress) &&
        Objects.equals(this.body, emailDetails.body) &&
        Objects.equals(this.toPartcipantAddress, emailDetails.toPartcipantAddress);
  }

  @Override
  public int hashCode() {
    return Objects.hash(fromAddress, body, toPartcipantAddress);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EmailDetails {\n");
    
    sb.append("    fromAddress: ").append(toIndentedString(fromAddress)).append("\n");
    sb.append("    body: ").append(toIndentedString(body)).append("\n");
    sb.append("    toPartcipantAddress: ").append(toIndentedString(toPartcipantAddress)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
