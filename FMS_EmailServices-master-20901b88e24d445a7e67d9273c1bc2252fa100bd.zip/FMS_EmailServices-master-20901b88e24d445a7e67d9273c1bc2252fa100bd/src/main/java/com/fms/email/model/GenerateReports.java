package com.fms.email.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * GenerateReports
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2020-01-24T12:20:46.638+05:30[Asia/Calcutta]")
public class GenerateReports {
	@JsonProperty("eventId")
	private String event_id = null;

	private String event_month = null;
	@JsonProperty("baseLocation")
	private String baselocation = null;

	@JsonProperty("beneficiaryName")
	private String beneficiary_name = null;

	@JsonProperty("councilName")
	private String council_name = null;

	@JsonProperty("project")
	private String project = null;

	@JsonProperty("category")
	private String category = null;

	@JsonProperty("eventDate")
	private String event_date = null;

	@JsonProperty("employeeId")
	private String employee_id = null;

	@JsonProperty("employeeName")
	private String employee_name = null;

	@JsonProperty("volunteerHours")
	private Integer volunteerHours = null;

	@JsonProperty("travelHours")
	private Integer travelHours = null;

	@JsonProperty("livesImpacted")
	private Integer livesImpacted = null;

	@JsonProperty("businessUnit")
	private String businessunit = null;

	@JsonProperty("status")
	private String event_status = null;

	@JsonProperty("IIEPCategory")
	private String iiepcategory = null;

	public String getEvent_id() {
		return event_id;
	}

	public void setEvent_id(String event_id) {
		this.event_id = event_id;
	}

	public String getEvent_month() {
		return event_month;
	}

	public void setEvent_month(String event_month) {
		this.event_month = event_month;
	}

	public String getBaselocation() {
		return baselocation;
	}

	public void setBaselocation(String baselocation) {
		this.baselocation = baselocation;
	}

	public String getBeneficiary_name() {
		return beneficiary_name;
	}

	public void setBeneficiary_name(String beneficiary_name) {
		this.beneficiary_name = beneficiary_name;
	}

	public String getCouncil_name() {
		return council_name;
	}

	public void setCouncil_name(String council_name) {
		this.council_name = council_name;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getEvent_date() {
		return event_date;
	}

	public void setEvent_date(String event_date) {
		this.event_date = event_date;
	}

	public String getEmployee_id() {
		return employee_id;
	}

	public void setEmployee_id(String employee_id) {
		this.employee_id = employee_id;
	}

	public String getEmployee_name() {
		return employee_name;
	}

	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}

	public Integer getVolunteerHours() {
		return volunteerHours;
	}

	public void setVolunteerHours(Integer volunteerHours) {
		this.volunteerHours = volunteerHours;
	}

	public Integer getTravelHours() {
		return travelHours;
	}

	public void setTravelHours(Integer travelHours) {
		this.travelHours = travelHours;
	}

	public Integer getLivesImpacted() {
		return livesImpacted;
	}

	public void setLivesImpacted(Integer livesImpacted) {
		this.livesImpacted = livesImpacted;
	}

	public String getBusinessunit() {
		return businessunit;
	}

	public void setBusinessunit(String businessunit) {
		this.businessunit = businessunit;
	}

	public String getEvent_status() {
		return event_status;
	}

	public void setEvent_status(String event_status) {
		this.event_status = event_status;
	}

	public String getIiepcategory() {
		return iiepcategory;
	}

	public void setIiepcategory(String iiepcategory) {
		this.iiepcategory = iiepcategory;
	}

}
