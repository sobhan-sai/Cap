package com.fms.email.Repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

import com.fms.email.entity.EventSummary;

@Repository
public interface OutReachEventsRepository extends ReactiveCrudRepository<EventSummary, Long> {


}