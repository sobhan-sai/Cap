package com.fms.email.Repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fms.email.entity.EventParticipantInfo;
import com.fms.email.service.EventParticipantInfoService;

@Service
public class EventParticipantRepositoryService implements EventParticipantInfoService {

	@Autowired
	private OutReachParticipantsEventsRepository repo;

	@Override
	public void saveEventParticipants(List<EventParticipantInfo> participantInfos) {
		repo.saveAll(participantInfos).log().subscribe(x -> System.out.println(x.getEmployee_id()));
	}

}
