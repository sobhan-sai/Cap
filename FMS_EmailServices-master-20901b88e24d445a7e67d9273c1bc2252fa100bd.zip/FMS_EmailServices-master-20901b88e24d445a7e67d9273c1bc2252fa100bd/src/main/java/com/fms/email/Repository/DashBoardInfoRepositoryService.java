package com.fms.email.Repository;

import java.util.Map;

import com.fms.email.service.DashboardService;

public class DashBoardInfoRepositoryService implements DashboardService{

	@Override
	public Map getDashboardSummary() {
		return null;
	}

}
