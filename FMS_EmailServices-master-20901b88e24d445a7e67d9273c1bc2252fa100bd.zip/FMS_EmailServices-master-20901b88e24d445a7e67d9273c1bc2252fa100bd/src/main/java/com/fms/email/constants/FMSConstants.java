package com.fms.email.constants;

public class FMSConstants {

	
	public static final String  OUTREACHEVENTINFO = "OutReachEventInfo" ;
	public static final String  OUTREACHEVENTSUMMARY = "OutreachEventSummary" ;
	public static final String  VOLUNTEERNOTATTENDED = "VolunteerNotAttended" ;
	public static final String  VOLUNTEERUNREGISTERED = "VolunteerUnregistered" ;
	
	public static final String UPLOADED_FILE_LOC="D:\\Users\\530532\\Postman\\NewFile\\";
}
