package com.fms.email.Repository;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

import com.fms.email.entity.EventSummary;

import reactor.core.publisher.Mono;

@Repository
public interface DashBoardSummaryRepository extends ReactiveCrudRepository<EventSummary, Long> {

	@Query("Select count(event_id) as eventId,sum(lives_impacted) livesImpacted , sum(total_no_of_volunteers) as totalNoOfVolunteers FROM EventSummary ")
	public Mono<DashboardInformation> getDashboardSummary();

}