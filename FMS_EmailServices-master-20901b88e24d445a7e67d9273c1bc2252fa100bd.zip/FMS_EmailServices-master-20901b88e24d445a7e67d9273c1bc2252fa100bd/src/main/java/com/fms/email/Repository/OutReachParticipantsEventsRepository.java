package com.fms.email.Repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

import com.fms.email.entity.EventParticipantInfo;

@Repository
public interface OutReachParticipantsEventsRepository extends ReactiveCrudRepository<EventParticipantInfo, Long> {

}