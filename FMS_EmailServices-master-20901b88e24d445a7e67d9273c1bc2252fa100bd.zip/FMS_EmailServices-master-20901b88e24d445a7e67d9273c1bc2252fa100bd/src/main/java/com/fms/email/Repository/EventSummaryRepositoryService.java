package com.fms.email.Repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fms.email.entity.EventSummary;
import com.fms.email.service.EventSummaryService;

@Service
public class EventSummaryRepositoryService implements EventSummaryService {

	@Autowired
	private OutReachEventsRepository repo;

	@Override
	public void saveEventSummary(List<EventSummary> eventSummaryList) {
		
		repo.saveAll(eventSummaryList);
	}

}
