package com.fms.email.handler;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.fms.email.Repository.DashBoardSummaryRepository;
import com.fms.email.entity.EventSummary;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class FMSHandler {
	private final DashBoardSummaryRepository dashBoardRepository;

	public FMSHandler(DashBoardSummaryRepository showRepository) {
		this.dashBoardRepository = showRepository;
	}

	public Mono<ServerResponse> all(ServerRequest serverRequest) {
		Flux<EventSummary> eventSummary = this.dashBoardRepository.findAll();
		
	
		return ServerResponse.ok().body(eventSummary, EventSummary.class);
	}
}
