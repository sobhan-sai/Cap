package com.fms.email.controller;

import java.util.Date;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fms.email.Repository.EventDetailsRepository;
import com.fms.email.entity.EmailInfo;
import com.fms.email.model.GenerateReports;
import com.fms.email.utils.FMSUtils;

import reactor.core.publisher.Mono;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2020-01-24T12:20:46.638+05:30[Asia/Calcutta]")
@RestController
@FeignClient(name = "netflix-zuul-api-gateway-server")
@RibbonClient(name="FMS_EventsInformations")
public class TriggerEmailsApiController implements TriggerEmailsApi {

	private final ObjectMapper objectMapper;

	private final HttpServletRequest request;
	@Autowired
	private DatabaseClient databaseClient;
	@Autowired
	EventDetailsRepository eventDetailsRepository;

	EmailInfo emailInfo = new EmailInfo();

	@org.springframework.beans.factory.annotation.Autowired
	public TriggerEmailsApiController(ObjectMapper objectMapper, HttpServletRequest request) {
		this.objectMapper = objectMapper;
		this.request = request;
	}

	@Override
	public Optional<ObjectMapper> getObjectMapper() {
		return Optional.ofNullable(objectMapper);
	}

	@Override
	public Optional<HttpServletRequest> getRequest() {
		return Optional.ofNullable(request);
	}

	public Mono<ResponseEntity<String>> triggerEmail(
			@Valid @PathVariable(value = "emailType", required = true) String emailType, String eventId) {

		// EVENTS_MAIL = "1"; EVENTSDETAILS_MAIL = "2"; REPORTS_MAIL = "3";

		emailInfo.setFromaddress("admin@admin.com");
		emailInfo.setSendon(new Date());

		if (emailType.equalsIgnoreCase(FMSUtils.EVENTS_MAIL)) {
//Send only 56-(4+3) = 49 recepients only 
			
			/*
			 * SELECT count(event_id) -((select count(event_id) from participantnotattended)
			 * + ( select count(event_id) from participantunregistered)) AS difference from
			 * eventparticipantinfo;
			 */

		} else if (emailType.equalsIgnoreCase(FMSUtils.EVENTSDETAILS_MAIL) && eventId != null) {

			eventDetailsRepository.findById(Long.parseLong(eventId)).subscribe(eventsList -> {
				emailInfo.setEventbody(eventsList.getEvent_description());
				emailInfo.setEventsubject(eventsList.getEventname());
				emailInfo.setEventid(eventsList.getEvent_id());

			});

		} else if (emailType.equalsIgnoreCase(FMSUtils.REPORTS_MAIL)) {

			databaseClient.execute(
					" select  es.event_id ,es.event_month,es.baselocation, es.beneficiary_name, es.council_name , es.project, es.category, \n"
							+ " ep.employee_id,ep.employee_name,ep.businessunit,ep.event_status,ep.iiepcategory \n"
							+ " from eventsummary  es ,eventparticipantinfo ep \n"
							+ " where es.event_id = ep.event_id ")
					.as(GenerateReports.class).fetch().all().subscribe(dashboard -> {
						emailInfo.setEventbody("");
						emailInfo.setEventsubject("");
						emailInfo.setEventid(dashboard.getEvent_id());

					}

					);

		}

		return null;

	}
}
