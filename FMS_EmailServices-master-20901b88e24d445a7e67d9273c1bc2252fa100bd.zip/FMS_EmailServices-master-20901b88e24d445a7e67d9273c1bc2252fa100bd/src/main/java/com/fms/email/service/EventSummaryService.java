package com.fms.email.service;

import java.util.List;

import com.fms.email.entity.EventSummary;

public interface EventSummaryService {

	 void saveEventSummary(List<EventSummary>  eventSummary);
	 
}
