export const LOGIN ='LOGIN';


export const login=(val) =>{
    return {
        type:LOGIN,
        value:val
    }
}


