package com.fms.entity;

import lombok.Data;

@Data
public class Dashboard {

	private String totalEvents;

	private String livesImpacted;

	private String totalVolunteers;

	private String totalParticipants;

}