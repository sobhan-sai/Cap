package com.cts.fms.usermanagement.repository;

import com.cts.fms.usermanagement.domain.FeedbackQuestion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeedbackQuestionRepository extends JpaRepository<FeedbackQuestion,Long> {
}
