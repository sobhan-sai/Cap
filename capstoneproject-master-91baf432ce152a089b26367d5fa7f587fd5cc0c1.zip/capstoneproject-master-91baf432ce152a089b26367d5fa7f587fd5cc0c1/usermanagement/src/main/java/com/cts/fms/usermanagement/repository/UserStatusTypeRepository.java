package com.cts.fms.usermanagement.repository;

import com.cts.fms.usermanagement.domain.UserStatusType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserStatusTypeRepository extends JpaRepository<UserStatusType,Long> {

}
