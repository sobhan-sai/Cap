package com.cts.fms.usermanagement.domain;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name="event")
public class Event {

    @Id
    @GeneratedValue
    private Long id;
    private String eventId;
    private String name;
    private String description;
    private String startDate;
    private String baseLocation;
    private String beneficiaryName;
    private String venueAddress;
    private String councilName;
    private String projectName;
    private String category;
    private String businessUnit;
    private String totalVolunteer;
    private String totalVolunteerHour;
    private String totalTravelHour;
    private String overallVolunterHour;
    private String livesImpacted;
    private String activityType;
    private String status;

    @OneToOne(targetEntity =  User.class)
    private User poc;

    @OneToMany(targetEntity = UserEventFeedbackResponse.class)
    private List<UserEventFeedbackResponse> userEventFeedbackResponseList;

    public Event(Long id, String name, String description, String startDate, String baseLocation, String beneficiaryName, String venueAddress, String councilName, String projectName, String category, String businessUnit, String totalVolunteer, String totalVolunteerHour, String totalTravelHour, String overallVolunterHour, String livesImpacted, String activityType, String status) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.startDate = startDate;
        this.baseLocation = baseLocation;
        this.beneficiaryName = beneficiaryName;
        this.venueAddress = venueAddress;
        this.councilName = councilName;
        this.projectName = projectName;
        this.category = category;
        this.businessUnit = businessUnit;
        this.totalVolunteer = totalVolunteer;
        this.totalVolunteerHour = totalVolunteerHour;
        this.totalTravelHour = totalTravelHour;
        this.overallVolunterHour = overallVolunterHour;
        this.livesImpacted = livesImpacted;
        this.activityType = activityType;
        this.status = status;
    }

    public Event() {

    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public List<UserEventFeedbackResponse> getUserEventFeedbackResponseList() {
        return userEventFeedbackResponseList;
    }

    public void setUserEventFeedbackResponseList(List<UserEventFeedbackResponse> userEventFeedbackResponseList) {
        this.userEventFeedbackResponseList = userEventFeedbackResponseList;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getBaseLocation() {
        return baseLocation;
    }

    public void setBaseLocation(String baseLocation) {
        this.baseLocation = baseLocation;
    }

    public String getBeneficiaryName() {
        return beneficiaryName;
    }

    public void setBeneficiaryName(String beneficiaryName) {
        this.beneficiaryName = beneficiaryName;
    }

    public String getVenueAddress() {
        return venueAddress;
    }

    public void setVenueAddress(String venueAddress) {
        this.venueAddress = venueAddress;
    }

    public String getCouncilName() {
        return councilName;
    }

    public void setCouncilName(String councilName) {
        this.councilName = councilName;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getBusinessUnit() {
        return businessUnit;
    }

    public void setBusinessUnit(String businessUnit) {
        this.businessUnit = businessUnit;
    }

    public String getTotalVolunteer() {
        return totalVolunteer;
    }

    public void setTotalVolunteer(String totalVolunteer) {
        this.totalVolunteer = totalVolunteer;
    }

    public String getTotalVolunteerHour() {
        return totalVolunteerHour;
    }

    public void setTotalVolunteerHour(String totalVolunteerHour) {
        this.totalVolunteerHour = totalVolunteerHour;
    }

    public String getTotalTravelHour() {
        return totalTravelHour;
    }

    public void setTotalTravelHour(String totalTravelHour) {
        this.totalTravelHour = totalTravelHour;
    }

    public String getOverallVolunterHour() {
        return overallVolunterHour;
    }

    public void setOverallVolunterHour(String overallVolunterHour) {
        this.overallVolunterHour = overallVolunterHour;
    }

    public String getLivesImpacted() {
        return livesImpacted;
    }

    public void setLivesImpacted(String livesImpacted) {
        this.livesImpacted = livesImpacted;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public User getPoc() {
        return poc;
    }

    public void setPoc(User poc) {
        this.poc = poc;
    }
}
