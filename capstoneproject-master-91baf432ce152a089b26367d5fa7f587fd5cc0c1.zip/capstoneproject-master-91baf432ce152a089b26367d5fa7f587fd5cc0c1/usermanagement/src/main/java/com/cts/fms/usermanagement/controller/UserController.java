package com.cts.fms.usermanagement.controller;

import com.cts.fms.usermanagement.domain.RecordNotFoundException;
import com.cts.fms.usermanagement.domain.User;
import com.cts.fms.usermanagement.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/user/api/v1")
public class UserController {

    UserRepository userRepository;

    public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @PostMapping(value = "/obtainUser")
    public ResponseEntity<User> findUserByUsername(@RequestBody User userIns) {
        String username = userIns.getUsername();
        userIns = userRepository.findByUsername(username);
        System.out.println("userIns"+userIns);
        if(userIns != null) {
            return new ResponseEntity<User>(userIns, HttpStatus.OK);
        } else {
            throw new RecordNotFoundException("Invalid username : " + username);
        }
    }

    @PostMapping(value = "/loginAuthentication",consumes = "application/json", produces = "application/json")
    public ResponseEntity<Boolean> loginAuthentication(@RequestBody User userIns) {
        String username = userIns.getUsername();
        String password = userIns.getPassword();
        userIns = userRepository.findByUsernameAndPassword(username,password);
        if(userIns != null) {
            return new ResponseEntity<Boolean>(Boolean.TRUE,HttpStatus.OK);
        } else {
            return new ResponseEntity<Boolean>(Boolean.FALSE,HttpStatus.OK);
        }
    }

}
