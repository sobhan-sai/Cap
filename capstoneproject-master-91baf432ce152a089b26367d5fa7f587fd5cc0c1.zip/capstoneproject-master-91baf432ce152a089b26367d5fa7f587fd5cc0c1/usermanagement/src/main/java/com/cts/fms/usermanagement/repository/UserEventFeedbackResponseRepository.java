package com.cts.fms.usermanagement.repository;

import com.cts.fms.usermanagement.domain.UserEventFeedbackResponse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserEventFeedbackResponseRepository extends JpaRepository<UserEventFeedbackResponse,Long> {
}
