package com.cts.fms.usermanagement.repository;

import com.cts.fms.usermanagement.domain.Event;
import com.cts.fms.usermanagement.domain.User;
import com.cts.fms.usermanagement.domain.UserEventRegistrationDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserEventRegistrationDetailRepository extends JpaRepository<UserEventRegistrationDetail,Long> {

    UserEventRegistrationDetail findByUserAndEvent(User userIns, Event eventIns);
}
