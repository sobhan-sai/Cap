import React from 'react';
import logo from './logo.svg';
import './App.css';
import "bootstrap/dist/css/bootstrap.min.css"
import Header from './components/global/Header';
import Login from './components/Login/Login';
import { Route, Link, BrowserRouter as Router } from 'react-router-dom';
import Dashboard from './components/Event/Dashboard';
import EventIndex from './components/Event/Index';
import EventInfo from './components/Event/EventInfo';

function App() {
  return (
    <div className="App">
      <Router>
        <Header />
        <div className="container">
          <Route exact path="/" component={Login}/>
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/event/index" component={EventIndex} />
          <Route path="/event/eventinfo" component={EventInfo} />
        </div>
      </Router>
    </div>
  );
}

export default App;
