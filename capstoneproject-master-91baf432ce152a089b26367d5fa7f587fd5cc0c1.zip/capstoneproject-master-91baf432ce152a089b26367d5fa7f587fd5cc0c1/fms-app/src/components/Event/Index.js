import React, { useState, useEffect } from "react";
import axios from "axios";
import Loading from "../global/Loading";
import { Link } from "react-router-dom";

const ViewEvents = React.memo(props => {
  const [eventList, setEventList] = useState([]);
  const [dataFetch, setDataFetch] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      const result = await axios("/event/api/v1/listAll");
      setEventList(result);
      setDataFetch(true);
    };

    fetchData();
  }, []);

  return (
    <React.Fragment>
      {dataFetch ? (
        <div>
          <div className="card">
            <div className="card-header" style={{ textAlign: "left" }}>
              List of Events
            </div>
            <div className="card-body">
              <div className="table-responsive">
                <table className="table table-sm table-bordered">
                  <thead>
                    <tr>
                      <th scope="col">Event Id</th>
                      <th scope="col">Name</th>
                      <th scope="col">Status</th>
                      <th scope="col">Venue Address</th>
                      <th scope="col">Total Volunteers</th>
                      <th scope="col">Total Volunteer Hours</th>
                      <th scope="col">Total Travel Hours</th>
                    </tr>
                  </thead>
                  <tbody>
                    {eventList.data.map(eventsIns => (
                      <tr key={eventsIns.id}>
                        <th scope="row">
                          <Link
                            to={{
                              pathname: "/event/eventinfo",
                              data: {
                                eventId: eventsIns.eventId
                              }
                            }}
                          >
                            {eventsIns.eventId}
                          </Link>
                        </th>
                        <td>{eventsIns.name}</td>
                        <td>{eventsIns.status}</td>
                        <td>{eventsIns.venueAddress}</td>
                        <td>{eventsIns.totalVolunteer}</td>
                        <td>{eventsIns.totalVolunteerHour}</td>
                        <td>{eventsIns.totalTravelHour}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <Loading />
      )}
    </React.Fragment>
  );
});

export default ViewEvents;
