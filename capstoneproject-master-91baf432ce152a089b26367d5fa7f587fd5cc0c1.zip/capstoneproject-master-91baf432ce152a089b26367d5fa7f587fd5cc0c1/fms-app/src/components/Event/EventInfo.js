import React,{ useState,useEffect } from "react";
import axios from 'axios';
import Loading from "../global/Loading";
import { Link } from "react-router-dom";

const EventInfo = React.memo( (props => {
    
    const [eventInfo,setEventInfo] = useState({});
    const [dataFetch,setDataFetch] = useState(false);

    useEffect( () => {
        let eventId = props.location.data.eventId;
        const fetchData = async () => {
            const result = await axios('/event/api/v1/findByEventId/'+eventId);
            setEventInfo(result);
            setDataFetch(true)
        }

        fetchData();
        

    },[])

    return(
        <React.Fragment>
            {
                dataFetch ?
                <div>
                <div className="row mb-4">
                    <div className="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                        <div className="card text-center">
                            <div className="card-header text-white bg-primary">
                                Featured
                            </div>
                            <div className="card-body">
                                <h5 className="card-title">Special title treatment</h5>
                                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                                
                            </div>
                            <div className="card-footer text-muted">
                                2 days ago
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                        <div className="card text-center">
                            <div className="card-header text-white bg-primary">
                                Featured
                            </div>
                            <div className="card-body">
                                <h5 className="card-title">Special title treatment</h5>
                                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                                
                            </div>
                            <div className="card-footer text-muted">
                                2 days ago
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row mb-4">
                    <div className="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                        <div className="card text-center">
                            <div className="card-header text-white bg-primary">
                                Featured
                            </div>
                            <div className="card-body">
                                <h5 className="card-title">Special title treatment</h5>
                                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                                
                            </div>
                            <div className="card-footer text-muted">
                                2 days ago
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                        <div className="card text-center">
                            <div className="card-header text-white bg-primary">
                                Featured
                            </div>
                            <div className="card-body">
                                <h5 className="card-title">Special title treatment</h5>
                                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                                
                            </div>
                            <div className="card-footer text-muted">
                                2 days ago
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                        <div className="card text-center">
                            <div className="card-header text-white bg-primary">
                                Featured
                            </div>
                            <div className="card-body">
                                <h5 className="card-title">Special title treatment</h5>
                                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                                
                            </div>
                            <div className="card-footer text-muted">
                                2 days ago
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row mb-4">
                    <div className="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                        <div className="card text-center">
                            <div className="card-header text-white bg-primary">
                                Featured
                            </div>
                            <div className="card-body">
                                <h5 className="card-title">Special title treatment</h5>
                                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                                
                            </div>
                            <div className="card-footer text-muted">
                                2 days ago
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                        <div className="card text-center">
                            <div className="card-header text-white bg-primary">
                                Featured
                            </div>
                            <div className="card-body">
                                <h5 className="card-title">Special title treatment</h5>
                                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                                
                            </div>
                            <div className="card-footer text-muted">
                                2 days ago
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                : <Loading />
            }
        </React.Fragment>
    )

}));

export default EventInfo;