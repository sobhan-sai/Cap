package com.cts.fms.feedbackmanagement.repository;

import com.cts.fms.feedbackmanagement.domain.FeedbackType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeedbackTypeRepository extends JpaRepository<FeedbackType,Long> {

    public FeedbackType findByName(String name);

}
