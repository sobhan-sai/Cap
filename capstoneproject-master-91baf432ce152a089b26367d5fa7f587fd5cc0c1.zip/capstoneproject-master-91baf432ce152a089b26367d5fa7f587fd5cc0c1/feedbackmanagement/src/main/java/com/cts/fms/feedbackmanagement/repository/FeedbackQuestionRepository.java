package com.cts.fms.feedbackmanagement.repository;

import com.cts.fms.feedbackmanagement.domain.FeedbackQuestion;
import com.cts.fms.feedbackmanagement.domain.FeedbackType;
import com.cts.fms.feedbackmanagement.domain.UserStatusType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FeedbackQuestionRepository extends JpaRepository<FeedbackQuestion,Long> {

    public FeedbackQuestion findByName(String name);

    public List<FeedbackQuestion> findByFeedbackType(FeedbackType feedbackType);

    public List<FeedbackQuestion> findByUserStatusType(UserStatusType userStatusType);

}
