package com.cts.fms.feedbackmanagement.repository;

import com.cts.fms.feedbackmanagement.domain.Event;
import com.cts.fms.feedbackmanagement.domain.User;
import com.cts.fms.feedbackmanagement.domain.UserEventRegistrationDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserEventRegistrationDetailRepository extends JpaRepository<UserEventRegistrationDetail,Long> {

    UserEventRegistrationDetail findByUserAndEvent(User userIns, Event eventIns);
}
