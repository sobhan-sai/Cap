package com.cts.fms.feedbackmanagement.repository;

import com.cts.fms.feedbackmanagement.domain.UserEventFeedbackResponse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserEventFeedbackResponseRepository extends JpaRepository<UserEventFeedbackResponse,Long> {
}
