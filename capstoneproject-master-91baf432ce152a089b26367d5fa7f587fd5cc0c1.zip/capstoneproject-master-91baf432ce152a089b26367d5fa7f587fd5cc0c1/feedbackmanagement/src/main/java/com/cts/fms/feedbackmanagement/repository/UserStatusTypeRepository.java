package com.cts.fms.feedbackmanagement.repository;

import com.cts.fms.feedbackmanagement.domain.UserStatusType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserStatusTypeRepository extends JpaRepository<UserStatusType,Long> {

    public UserStatusType findByName(String name);

}
