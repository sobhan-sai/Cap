package com.cts.fms.feedbackmanagement.repository;

import com.cts.fms.feedbackmanagement.domain.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role,Long> {



}
