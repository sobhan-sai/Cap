package com.cts.fms.feedbackmanagement.controller;

import com.cts.fms.feedbackmanagement.domain.FeedbackAnswer;
import com.cts.fms.feedbackmanagement.domain.FeedbackQuestion;
import com.cts.fms.feedbackmanagement.domain.FeedbackType;
import com.cts.fms.feedbackmanagement.domain.UserStatusType;
import com.cts.fms.feedbackmanagement.repository.FeedbackAnswerRepository;
import com.cts.fms.feedbackmanagement.repository.FeedbackQuestionRepository;
import com.cts.fms.feedbackmanagement.repository.FeedbackTypeRepository;
import com.cts.fms.feedbackmanagement.repository.UserStatusTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/feedbackQuestion/api/v1")
public class FeedbackController {

    @Autowired
    private FeedbackQuestionRepository feedbackQuestionRepository;

    @Autowired
    private FeedbackAnswerRepository feedbackAnswerRepository;

    @Autowired
    private FeedbackTypeRepository feedbackTypeRepository;

    @Autowired
    private UserStatusTypeRepository userStatusTypeRepository;

    @GetMapping("/listAll")
    public List<FeedbackQuestion> listAll() {
        return feedbackQuestionRepository.findAll();
    }

    @GetMapping("/{id}")
    public Optional<FeedbackQuestion> findById(@PathVariable String id) {
        return feedbackQuestionRepository.findById(Long.parseLong(id));
    }

    @PostMapping("/findByFeedbackName")
    public FeedbackQuestion findByFeedbackName(@RequestBody FeedbackQuestion feedbackQuestion){
        String name = feedbackQuestion.getName();
        return feedbackQuestionRepository.findByName(name);
    }

    @PostMapping("/findByFeedbackType")
    public List<FeedbackQuestion> findByFeedbackType(@RequestBody FeedbackType feedbackType){
        FeedbackType feedbackTypeIns = feedbackTypeRepository.findByName(feedbackType.getName());
        return feedbackQuestionRepository.findByFeedbackType(feedbackTypeIns);
    }

    @PostMapping("/findByUserStatusType")
    public List<FeedbackQuestion> findByUserStatusType(@RequestBody UserStatusType userStatusType){
        UserStatusType userStatusTypeIns = userStatusTypeRepository.findByName(userStatusType.getName());
        return feedbackQuestionRepository.findByUserStatusType(userStatusTypeIns);
    }

}
