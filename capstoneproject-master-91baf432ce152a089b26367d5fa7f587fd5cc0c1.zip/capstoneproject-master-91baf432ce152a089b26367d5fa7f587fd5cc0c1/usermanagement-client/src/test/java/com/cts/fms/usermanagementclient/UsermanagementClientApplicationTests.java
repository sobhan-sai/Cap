package com.cts.fms.usermanagementclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsermanagementClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
