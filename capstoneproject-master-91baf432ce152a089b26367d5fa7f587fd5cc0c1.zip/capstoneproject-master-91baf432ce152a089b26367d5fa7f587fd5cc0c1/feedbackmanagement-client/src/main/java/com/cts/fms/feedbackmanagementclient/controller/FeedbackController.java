package com.cts.fms.feedbackmanagementclient.controller;

import com.cts.fms.feedbackmanagementclient.domain.FeedbackQuestion;
import com.cts.fms.feedbackmanagementclient.domain.FeedbackType;
import com.cts.fms.feedbackmanagementclient.domain.UserStatusType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/feedback/api/v1")
public class FeedbackController {

    @Autowired
    private WebClient.Builder webClientBuilder;

    @GetMapping("/listAll")
    public Flux<FeedbackQuestion> listAll() {
        return webClientBuilder.build().get()
                .uri("http://feedbackmanagement-service/feedbackQuestion/api/v1/listAll")
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToFlux(FeedbackQuestion.class).log();
    }

    @GetMapping("/{id}")
    public Mono<FeedbackQuestion> findById(@PathVariable String id){
        return webClientBuilder.build().get()
                .uri("http://feedbackmanagement-service/feedbackQuestion/api/v1/"+id)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(FeedbackQuestion.class).log();
    }

    @PostMapping("/findByFeedbackName")
    public Mono<FeedbackQuestion> findByFeedbackName(@RequestBody FeedbackQuestion feedbackQuestion) {
        Mono<FeedbackQuestion> feedbackQuestionMono = Mono.just(feedbackQuestion);
        return webClientBuilder.build().post()
                .uri("http://feedbackmanagement-service/feedbackQuestion/api/v1/findByFeedbackName")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .body(feedbackQuestionMono,FeedbackQuestion.class)
                .retrieve()
                .bodyToMono(FeedbackQuestion.class).log();

    }

    @PostMapping("/findByFeedbackType")
    public Flux<FeedbackQuestion> findByFeedbackType(@RequestBody FeedbackType feedbackType) {
        Mono<FeedbackType> feedbackTypeMono = Mono.just(feedbackType);
        return webClientBuilder.build().post()
                .uri("http://feedbackmanagement-service/feedbackQuestion/api/v1/findByFeedbackType")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .body(feedbackTypeMono,FeedbackType.class)
                .retrieve()
                .bodyToFlux(FeedbackQuestion.class).log();
    }

    @PostMapping("/findByUserStatusType")
    public Flux<FeedbackQuestion> findByUserStatusType(@RequestBody UserStatusType userStatusType) {
        Mono<UserStatusType> userStatusTypeMono = Mono.just(userStatusType);
        return webClientBuilder.build().post()
                .uri("http://feedbackmanagement-service/feedbackQuestion/api/v1/findByUserStatusType")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .body(userStatusTypeMono,UserStatusType.class)
                .retrieve()
                .bodyToFlux(FeedbackQuestion.class).log();
    }


}
