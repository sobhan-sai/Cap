package com.cts.fms.feedbackmanagementclient.controller;

import com.cts.fms.feedbackmanagementclient.domain.Event;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/event/api/v1/")
public class EventController {

    @Autowired
    private WebClient.Builder webClientBuilder;

    @GetMapping("/listAll")
    public Flux<Event> listAll() {
        return webClientBuilder.build().get()
                .uri("http://eventmanagement-service/event/api/v1/listAll")
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToFlux(Event.class).log();
    }

    @GetMapping("/findByEventId/{eventId}")
    public Mono<Event> findByEventId(@PathVariable  String eventId) {
        return webClientBuilder.build().get()
                .uri("http://eventmanagement-service/event/api/v1/findByEventId/"+eventId)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(Event.class).log();
    }

}
