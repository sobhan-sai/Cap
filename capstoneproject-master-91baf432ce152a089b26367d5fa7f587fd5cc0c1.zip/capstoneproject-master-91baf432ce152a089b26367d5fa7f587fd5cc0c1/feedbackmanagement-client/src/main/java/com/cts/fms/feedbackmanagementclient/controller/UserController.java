package com.cts.fms.feedbackmanagementclient.controller;

import com.cts.fms.feedbackmanagementclient.domain.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/user/api/v1")
public class UserController {

    @Autowired
    private WebClient.Builder webClientBuilder;

    @PostMapping("/obtainUser")
    public Mono<User> findUserByUsername(@RequestBody User user) {
        Mono<User> userMono = Mono.just(user);
        return webClientBuilder.build().post()
                .uri("http://usermanagement-service/user/api/v1/obtainUser")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .body(userMono,User.class)
                .retrieve()
                .bodyToMono(User.class).log();
    }

}
