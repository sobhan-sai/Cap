package com.cts.fms.feedbackmanagementclient.domain;

import java.util.List;

public class UserEventFeedbackResponse {

    private Long id;

    private User participant;

    private Double overallRating;

    private Event event;

    private List<FeedbackQuestion> feedbackQuestionList;

    public UserEventFeedbackResponse(){}

    public UserEventFeedbackResponse(User participant, Double overallRating, Event event) {
        this.participant = participant;
        this.overallRating = overallRating;
        this.event = event;
    }

    public User getParticipant() {
        return participant;
    }

    public void setParticipant(User participant) {
        this.participant = participant;
    }

    public Double getOverallRating() {
        return overallRating;
    }

    public void setOverallRating(Double overallRating) {
        this.overallRating = overallRating;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }
}
