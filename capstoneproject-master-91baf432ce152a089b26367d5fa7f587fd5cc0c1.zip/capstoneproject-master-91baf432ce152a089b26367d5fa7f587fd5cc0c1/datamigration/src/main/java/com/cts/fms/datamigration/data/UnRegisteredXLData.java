package com.cts.fms.datamigration.data;

public class UnRegisteredXLData {
}
