package com.cts.fms.datamigration.repository;

import com.cts.fms.datamigration.domain.Event;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EventRepository extends JpaRepository<Event,Long> {

    Event findByEventId(String eventId);
}
