package com.cts.fms.datamigration.controller;


import com.cts.fms.datamigration.data.ParticipatedXLData;
import com.cts.fms.datamigration.domain.*;
import com.cts.fms.datamigration.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Optional;

@RestController
@RequestMapping("/datamigration")
public class DataMigrationController {

    @Autowired
    EventRepository eventRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    RoleRepository roleRepository;

    @Autowired
    UserStatusTypeRepository userStatusTypeRepository;

    @Autowired
    UserEventRegistrationDetailRepository userEventRegistrationDetailRepository;

    public static final String EVENT_DETAILS = "/Users/cramarnath/Downloads/Outreach_Events_Summary.xlsx";
    public static final String USER_ATTEMPTED = "/Users/cramarnath/Downloads/OutReach_Event_Information.xlsx";
    public static final String USER_NOT_ATTEMPTED = "/Users/cramarnath/Downloads/OutReach_Event_Information.xlsx";
    public static final String USER_UN_REGISTERED = "/Users/cramarnath/Downloads/OutReach_Event_Information.xlsx";

    @GetMapping("/importEvents")
    public String importEvents() throws IOException, InvalidFormatException {
        Workbook workbook = WorkbookFactory.create(new File(EVENT_DETAILS));
        Sheet sheet = workbook.getSheetAt(0);
        DataFormatter dataFormatter = new DataFormatter();
        System.out.println("\n\nIterating over Rows and Columns using Java 8 forEach with lambda\n");
        int index = 0;
        for (Row row : sheet) {
            if (index != 0) {

                String eventId = dataFormatter.formatCellValue(row.getCell(0));
                String baseLocation = dataFormatter.formatCellValue(row.getCell(2   ));
                String beneficiaryName = dataFormatter.formatCellValue(row.getCell(3));
                String venueAddress = dataFormatter.formatCellValue(row.getCell(4));
                String councilName = dataFormatter.formatCellValue(row.getCell(5));
                String project = dataFormatter.formatCellValue(row.getCell(6));
                String category = dataFormatter.formatCellValue(row.getCell(7));
                String eventName = dataFormatter.formatCellValue(row.getCell(8));
                String eventDescription = dataFormatter.formatCellValue(row.getCell(9));
                String eventDate = dataFormatter.formatCellValue(row.getCell(10));
                String totalVolunters = dataFormatter.formatCellValue(row.getCell(11));
                String totalVolunteerHours = dataFormatter.formatCellValue(row.getCell(12));
                String travelHours = dataFormatter.formatCellValue(row.getCell(13));
                String overAllVolunteerHours = dataFormatter.formatCellValue(row.getCell(14));
                String livesImpacted = dataFormatter.formatCellValue(row.getCell(15));
                String activityType = dataFormatter.formatCellValue(row.getCell(16));
                String status = dataFormatter.formatCellValue(row.getCell(17));

                String employeeId = dataFormatter.formatCellValue(row.getCell(18));
                String employeeName = dataFormatter.formatCellValue(row.getCell(19));
                String mobile = dataFormatter.formatCellValue(row.getCell(20));

                User userIns = userRepository.findByUsername(employeeId);
                Optional<Role> roleIns = roleRepository.findById(3l);

                if(userIns == null) {
                    userIns = new User();
                    userIns.setUsername(employeeId);
                    userIns.setPassword(employeeId);
                    userIns.setName(employeeName);
                    userIns.setMobile(mobile);
                    userIns.setRole(roleIns.get());
                    userRepository.save(userIns);
                }

                Event eventIns = eventRepository.findByEventId(eventId);

                if(eventIns == null) {
                    eventIns = new Event();
                    eventIns.setEventId(eventId);
                    eventIns.setBaseLocation(baseLocation);
                    eventIns.setBeneficiaryName(beneficiaryName);
                    eventIns.setVenueAddress(venueAddress);
                    eventIns.setCouncilName(councilName);
                    eventIns.setProjectName(project);
                    eventIns.setName(eventName);
                    eventIns.setDescription(eventDescription);
                    eventIns.setStartDate(eventDate);
                    eventIns.setTotalVolunteer(totalVolunters);
                    eventIns.setTotalVolunteerHour(totalVolunteerHours);
                    eventIns.setTotalTravelHour(travelHours);
                    eventIns.setOverallVolunterHour(overAllVolunteerHours);
                    eventIns.setLivesImpacted(livesImpacted);
                    eventIns.setActivityType(activityType);
                    eventIns.setStatus(status);
                    eventIns.setCategory(category);
                    eventIns.setPoc(userIns);
                    eventRepository.save(eventIns);
                }
            }
            index++;
        }
        workbook.close();
        return "Imported";
    }

    @GetMapping("/importAttemptedUsers")
    public String importAttemptedUsers() throws IOException, InvalidFormatException {
        Workbook workbook = WorkbookFactory.create(new File(USER_ATTEMPTED));
        Sheet sheet = workbook.getSheetAt(0);
        DataFormatter dataFormatter = new DataFormatter();
        System.out.println("\n\nIterating over Rows and Columns using Java 8 forEach with lambda\n");
        int index = 0;
        for (Row row : sheet) {
            if (index != 0) {

                String eventId = dataFormatter.formatCellValue(row.getCell(0));
                String username = dataFormatter.formatCellValue(row.getCell(7));
                String participantName = dataFormatter.formatCellValue(row.getCell(8));

                Event eventIns = eventRepository.findByEventId(eventId);
                User userIns = userRepository.findByUsername(username);
                Optional<Role> roleIns = roleRepository.findById(4l);

                if(userIns == null) {
                    userIns = new User();
                    userIns.setName(participantName);
                    userIns.setUsername(username);
                    userIns.setPassword(username);
                    userIns.setRole(roleIns.get());
                    userRepository.save(userIns);
                }

                Optional<UserStatusType> userStatusTypeIns = userStatusTypeRepository.findById(1l);

                System.out.println("eventIns"+eventIns);
                System.out.println("userIns"+userIns);
                System.out.println("userStatusTypeIns"+userStatusTypeIns);

                UserEventRegistrationDetail userEventRegistrationDetailIns = userEventRegistrationDetailRepository.findByUserAndEvent(userIns,eventIns);

                if(userEventRegistrationDetailIns == null) {
                    userEventRegistrationDetailIns = new UserEventRegistrationDetail();
                    userEventRegistrationDetailIns.setUser(userIns);
                    userEventRegistrationDetailIns.setEvent(eventIns);
                    userEventRegistrationDetailIns.setUserStatusType(userStatusTypeIns.get());
                    userEventRegistrationDetailRepository.save(userEventRegistrationDetailIns);
                }
            }
            index++;
        }
        workbook.close();
        return "Imported";
    }

    @GetMapping("/importNotAttemptedUsers")
    public String importNotAttemptedUsers() throws IOException, InvalidFormatException {
        Workbook workbook = WorkbookFactory.create(new File(USER_NOT_ATTEMPTED));
        Sheet sheet = workbook.getSheetAt(0);
        DataFormatter dataFormatter = new DataFormatter();
        System.out.println("\n\nIterating over Rows and Columns using Java 8 forEach with lambda\n");
        int index = 0;
        for (Row row : sheet) {
            if (index != 0) {

            }
            index++;
        }
        workbook.close();
        return "Imported";
    }

    @GetMapping("/importUnRegisteredUsers")
    public String importUnRegisteredUsers() throws IOException, InvalidFormatException {
        Workbook workbook = WorkbookFactory.create(new File(USER_UN_REGISTERED));
        Sheet sheet = workbook.getSheetAt(0);
        DataFormatter dataFormatter = new DataFormatter();
        System.out.println("\n\nIterating over Rows and Columns using Java 8 forEach with lambda\n");
        int index = 0;
        for (Row row : sheet) {
            if (index != 0) {

            }
            index++;
        }
        workbook.close();
        return "Imported";
    }


}
