package com.cts.fms.datamigration.repository;

import com.cts.fms.datamigration.domain.FeedbackType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeedbackTypeRepository extends JpaRepository<FeedbackType,Long> {
}
