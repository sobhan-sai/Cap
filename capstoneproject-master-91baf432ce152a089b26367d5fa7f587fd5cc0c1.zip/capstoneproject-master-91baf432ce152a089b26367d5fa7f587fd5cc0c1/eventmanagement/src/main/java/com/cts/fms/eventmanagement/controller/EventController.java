package com.cts.fms.eventmanagement.controller;

import com.cts.fms.eventmanagement.domain.Event;
import com.cts.fms.eventmanagement.domain.User;
import com.cts.fms.eventmanagement.repository.EventRepository;
import com.cts.fms.eventmanagement.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/event/api/v1/")
public class EventController {

    @Autowired
    EventRepository eventRepository;

    @Autowired
    UserRepository userRepository;

    @GetMapping("/listAll")
    public List<Event> eventList() {
        return eventRepository.findAll();
    }

    @PostMapping("/findEventByUser")
    public List<Event> findEventByUser(@RequestBody User userIns) {
        User poc = userRepository.findByUsername(userIns.getUsername());
        List<Event> eventList = eventRepository.findByPoc(poc);
        return eventList;
    }

    @GetMapping("/findByEventId/{eventId}")
    public Event findById(@PathVariable String eventId) {
        System.out.println("eventId"+eventId);
        Event eventIns = eventRepository.findByEventId(eventId);
        System.out.println("eventIns"+eventIns);
        return eventIns;
    }

}
