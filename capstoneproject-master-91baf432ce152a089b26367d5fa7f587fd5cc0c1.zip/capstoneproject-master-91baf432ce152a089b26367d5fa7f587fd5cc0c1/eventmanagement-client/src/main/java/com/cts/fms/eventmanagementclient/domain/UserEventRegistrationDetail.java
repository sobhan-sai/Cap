package com.cts.fms.eventmanagementclient.domain;


public class UserEventRegistrationDetail {

    private Long id;

    private User user;

    private Event event;

    private UserStatusType userStatusType;

    public UserEventRegistrationDetail() {}

    public UserEventRegistrationDetail(Long id, User user, Event event) {
        this.id = id;
        this.user = user;
        this.event = event;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }

    public UserStatusType getUserStatusType() {
        return userStatusType;
    }

    public void setUserStatusType(UserStatusType userStatusType) {
        this.userStatusType = userStatusType;
    }
}
