package com.cts.fms.eventmanagementclient.controller;

import com.cts.fms.eventmanagementclient.domain.Event;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/event/api/v1/")
public class EventController {

    @Autowired
    private WebClient.Builder webClientBuilder;

    @GetMapping("/listAll")
    public Flux<Event> listAll() {
        return webClientBuilder.build().get()
                .uri("http://eventmanagement-service/event/api/v1/listAll")
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToFlux(Event.class).log();
    }

}
